from Algorithms.log_reg import LogRegCv
from Algorithms.svm import SVM_kernels
from Algorithms.neural_net import MultiLayerP
